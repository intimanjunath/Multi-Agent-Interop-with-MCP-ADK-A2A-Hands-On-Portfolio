import os
import vertexai
from .agent import root_agent
from vertexai import agent_engines

PROJECT_ID = "multi-agent-system-477901"
LOCATION = "us-central1"
STAGING_BUCKET = "gs://agent-engine-staging-multi-agent-system-477901"

vertexai.init(project=PROJECT_ID, location=LOCATION, staging_bucket=STAGING_BUCKET)

WHEEL_PATH = "./dist/image_scoring-0.1.0-py3-none-any.whl"

remote_app = agent_engines.create(
    agent_engine=root_agent,
    # Only PyPI-style deps in requirements:
    requirements=open(os.path.join(os.getcwd(), "requirements.txt")).read().splitlines(),
    # Your local package goes here:
    extra_packages=[WHEEL_PATH],
    # DO NOT set reserved envs like GOOGLE_CLOUD_PROJECT/GOOGLE_CLOUD_LOCATION.
    # Keep only app-specific ones:
    env_vars={
        "GOOGLE_GENAI_USE_VERTEXAI": "1",
        "GOOGLE_CLOUD_STORAGE_BUCKET": "gs://multi-agent-system-477901-imagescoring",
        "GCS_BUCKET_NAME": "gs://multi-agent-system-477901-imagescoring",
        "IMAGEN_MODEL": "imagen-3.0-generate-002",
        "GENAI_MODEL": "gemini-2.5-flash",
        "SCORE_THRESHOLD": "40",
    },
)

print(remote_app.resource_name)
